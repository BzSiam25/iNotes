-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2024 at 06:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `notes`
--

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `Serial NO.` int(100) NOT NULL,
  `Title` varchar(500) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  `Date and Time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`Serial NO.`, `Title`, `Description`, `Date and Time`) VALUES
(1, '1', '1', '2024-10-06 20:38:55'),
(2, '2', '2', '2024-10-06 20:39:06'),
(3, 'Vocation', 'From 9th October to 19th October i will go for a vocation.\r\nSo everyone keep me in your prayer.', '2024-10-06 20:54:11'),
(4, 'Vocation', 'From 9th October to 19th October i will go for a vocation.\r\nSo everyone keep me in your prayer.', '2024-10-06 20:54:19'),
(5, 'Vocation', 'From 9th October to 19th October i will go for a vocation.\r\nSo everyone keep me in your prayer.', '2024-10-06 20:54:21'),
(6, 'Vocation', 'From 9th October to 19th October i will go for a vocation.\r\nSo everyone keep me in your prayer.', '2024-10-06 20:55:41'),
(7, 'Vocation', 'From 9th October to 19th October i will go for a vocation.\r\nSo everyone keep me in your prayer.', '2024-10-06 20:55:45'),
(8, 'Vocation', 'From 9th October to 19th October i will go for a vocation.\r\nSo everyone keep me in your prayer.', '2024-10-06 21:05:23'),
(9, '4', '4', '2024-10-06 21:05:39'),
(10, '4', '4', '2024-10-06 21:08:08'),
(11, 'Home', 'I have to go home.', '2024-10-06 21:21:33'),
(12, 'Home', 'I have to go home.', '2024-10-06 21:28:00'),
(13, 'g', 'g', '2024-10-06 21:30:03'),
(16, 'cc', 'ccc', '2024-10-06 21:36:37'),
(18, 'fsfdfsd', 'swdhgetfnjwertj', '2024-10-16 14:31:31'),
(19, 'fsfdfsd', 'swdhgetfnjwertj', '2024-10-16 14:43:24'),
(20, 'fsfdfsd', 'swdhgetfnjwertj', '2024-10-16 14:43:27'),
(21, 'fsfdfsd', 'swdhgetfnjwertj', '2024-10-16 14:44:14'),
(22, 'fsfdfsd', 'swdhgetfnjwertj', '2024-10-16 14:47:13'),
(23, '1', '1', '2024-10-16 17:34:21'),
(24, '4f', '4fffff', '2024-10-16 17:34:33'),
(25, '4f', '4fffff', '2024-10-16 17:37:35'),
(26, '4f', '4fffff', '2024-10-16 17:41:17'),
(27, '4f', '4fffff', '2024-10-16 17:42:02'),
(28, '4f', '4fffff', '2024-10-16 17:52:48'),
(29, '4f', '4fffff', '2024-10-16 17:53:15'),
(30, '4f', '4fffff', '2024-10-16 17:57:26'),
(31, '4f', '4fffff', '2024-10-16 17:57:26'),
(32, '4f', '4fffff', '2024-10-16 18:02:44'),
(33, 'Siam', 'I am a student.', '2024-10-19 15:26:43'),
(34, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 15:27:16'),
(35, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:04:23'),
(36, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:06:51'),
(37, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:07:14'),
(38, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:07:32'),
(39, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:17:41'),
(40, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:20:00'),
(41, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:22:42'),
(42, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:24:58'),
(43, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:30:19'),
(44, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:30:57'),
(45, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:31:09'),
(46, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:42:33'),
(47, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:42:52'),
(48, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:59:21'),
(49, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 16:59:39'),
(50, '4f', '4ffffffffffffffffffffffffffff', '2024-10-19 17:00:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`Serial NO.`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `Serial NO.` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
