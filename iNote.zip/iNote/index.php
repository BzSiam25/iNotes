<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>iNotes - Notes making our life easy.</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
   
  </head>

  <body>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="editModalLabel">Edit this note.</h1>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        <form action="index.php?update=true" method="post">
          <input type="hidden" name="SerialNoEdit" id="SerialNoEdit">
          <div class="mb-3">
              <label for="TitleEdit" class="form-label">Note Title</label>
              <input type="text" class="form-control" id="TitleEdit" name="Title">
          </div>
          <div class="mb-3">
              <label for="DescriptionEdit" class="form-label">Description of the Note</label>
              <textarea class="form-control" id="DescriptionEdit" name="Description" style="height: 100px"></textarea>
          </div>
          <button type="submit" class="btn btn-primary mt-3">Update Note</button>
        </form>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Navigation -->
<nav class="navbar navbar-expand-lg" style="background-color: rgb(59, 56, 56);">
  <div class="container-fluid">
    <a class="navbar-brand" href="#" style="color: rgba(248, 241, 241, 0.797);">iNotes</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#" style="color: rgba(248, 241, 241, 0.797);">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#" style="color: rgba(248, 241, 241, 0.797);">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#" style="color: rgba(248, 241, 241, 0.797);">Contact Us</a>
        </li>
      </ul>
      <form class="d-flex ml-auto" role="search" style="width: 250px;">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit" style="color: rgba(248, 241, 241, 0.797); border-color: rgb(26, 25, 25);">Search</button>
      </form>
    </div>
  </div>
</nav>

<div class="container my-4">
  <h2>Add a Note!</h2>
  <form action="index.php" method="post">
    <div class="mb-3">
      <label for="Title" class="form-label">Note Title</label>
      <input type="text" class="form-control" id="Title" name="Title" required>
    </div>
    <div class="mb-3">
      <label for="Description" class="form-label">Description of the Note</label>
      <textarea class="form-control" id="Description" name="Description" style="height: 100px" required></textarea>
    </div>
    <button type="submit" class="btn btn-primary mt-3">Add Note</button>
  </form>

  <table class="table" id="mytable">
    <thead>
      <tr>
        <th scope="col">Serial No.</th>
        <th scope="col">Title</th>
        <th scope="col">Description</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
    <?php
    require_once 'connectDB.php'; // Ensure database connection file exists

    // Fetch notes from database
    $sql = "SELECT * FROM notes";  
    $result = mysqli_query($conn, $sql); 
    
    if (!$result) {
        die("Query failed: " . mysqli_error($conn));
    }

    $SerialNO = 0;
    while ($row = mysqli_fetch_assoc($result)) { 
        $SerialNO += 1;
        echo "<tr>
            <th scope='row'>" . $SerialNO . "</th>
            <td>" . $row['Title'] . "</td>
            <td>" . $row['Description'] . "</td>
            <td> 
  <button class='edit btn btn-sm btn-primary' id='" . $row['SerialNo'] . "'>Edit</button>
  <button class='delete btn btn-sm btn-danger' id='d" . $row['SerialNo'] . "'>Delete</button>
</td>

          </tr>";
    }
    
    // Handle deletion of notes
    if (isset($_GET['delete'])) {
        $SerialNo = $_GET['delete'];
        $sql = "DELETE FROM notes WHERE SerialNo = $SerialNo";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>
                    <strong>Success!</strong> Note has been deleted successfully.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                      <span aria-hidden='true'>&times;</span>
                    </button>
                  </div>";
        } else {
            echo "Error deleting record: " . mysqli_error($conn);
        }
    }
    ?>
    </tbody>
  </table>
</div>

<!-- Optional JavaScript -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>

<script>
  $(document).ready(function () {
    $('#mytable').DataTable();
  });

  // Attach click event to all elements with class 'edit'
  document.querySelectorAll('.edit').forEach(element => {
    element.addEventListener('click', (e) => {
      let tr = e.target.closest('tr');
      let title = tr.querySelectorAll('td')[0].innerText;
      let description = tr.querySelectorAll('td')[1].innerText;

      document.getElementById('TitleEdit').value = title;
      document.getElementById('DescriptionEdit').value = description;
      document.getElementById('SerialNoEdit').value = e.target.id;

      $('#editModal').modal('toggle');
    });
  });

  // Attach click event to all elements with class 'delete'
  document.querySelectorAll('.delete').forEach(element => {
    element.addEventListener('click', (e) => {
      let serialNo = e.target.id.substring(1);
      if (confirm("Are you sure you want to delete this note?")) {
          window.location = `index.php?delete=${serialNo}`;
      }
    });
  });
</script>

  </body>
</html>
