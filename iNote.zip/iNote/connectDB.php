<?php
// Database connection details
$servername = "localhost"; // Usually "localhost" for local development
$username = "root";        // Database username (default is "root" for XAMPP)
$password = "";            // Database password (empty by default for XAMPP)
$dbname = "notes";          // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$insert = false;

// Debugging check for 'SerialNoEdit'
if (isset($_POST['SerialNoEdit'])) {
    echo "SerialNoEdit: " . htmlspecialchars($_POST['SerialNoEdit']);
}

// Debugging check for 'Update' in the query string
if (isset($_GET['Update'])) {
    echo "Update: " . htmlspecialchars($_GET['Update']);
}

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Use mysqli_real_escape_string to prevent SQL injection
    $Title = mysqli_real_escape_string($conn, $_POST['Title']);
    $Description = mysqli_real_escape_string($conn, $_POST['Description']);

    // Validate input fields are not empty
    if (!empty($Title) && !empty($Description)) {
        // Prepare the SQL query
        $sql = "INSERT INTO notes (Title, Description) VALUES ('$Title', '$Description')";
        
        // Execute the query and check for success
        if (mysqli_query($conn, $sql)) {
            $insert = true;
            echo "Note added successfully!<br>";
        } else {
            // Print the error if the query fails
            echo "Error adding note: " . mysqli_error($conn);
        }
    } else {
        echo "Title and Description cannot be empty.";
    }
}

?>
